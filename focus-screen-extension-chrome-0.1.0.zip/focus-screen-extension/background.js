(function() {
  "use strict";
  const EXTENSION_PORT = 47833;
  const PROTOCOL_VERSION = 1;
  const MAX_ARTWORK_BYTES = 2 * 1024 * 1024;
  function isArtworkUrl(value) {
    let url;
    try {
      url = new URL(value);
    } catch {
      return false;
    }
    const host = url.hostname;
    return url.protocol === "https:" && !url.username && !url.password && !url.port && (host.endsWith(".googleusercontent.com") || host === "i.ytimg.com" || host.endsWith(".ggpht.com"));
  }
  const PAGE_LINE = "focus-screen-page";
  const ext = typeof browser !== "undefined" && browser ? browser : chrome;
  function chooseTab(tabs2, current) {
    const withSong = [...tabs2].filter(([, entry]) => entry.state !== null);
    const playing = withSong.filter(([, entry]) => entry.state?.playing);
    if (playing.some(([id]) => id === current)) return current;
    if (playing[0]) return playing[0][0];
    if (withSong.some(([id]) => id === current)) return current;
    const latest = withSong.sort(([, a], [, b]) => b.at - a.at)[0];
    return latest ? latest[0] : null;
  }
  function toBase64(bytes) {
    let binary = "";
    const chunk = 32768;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
    }
    return btoa(binary);
  }
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function parseCommand(raw) {
    if (!isRecord(raw)) return null;
    switch (raw.kind) {
      case "playPause":
      case "next":
      case "previous":
      case "restart":
        return { kind: raw.kind };
      case "setShuffle":
        return typeof raw.on === "boolean" ? { kind: "setShuffle", on: raw.on } : null;
      case "setRepeat":
        return raw.mode === "off" || raw.mode === "all" || raw.mode === "one" ? { kind: "setRepeat", mode: raw.mode } : null;
      case "seek":
        return typeof raw.positionSec === "number" && Number.isFinite(raw.positionSec) && raw.positionSec >= 0 ? { kind: "seek", positionSec: raw.positionSec } : null;
      default:
        return null;
    }
  }
  function parseAppMessage(raw) {
    if (!isRecord(raw)) return null;
    switch (raw.type) {
      case "welcome":
      case "keepalive":
        return { type: raw.type };
      case "paired":
        return typeof raw.token === "string" && raw.token.length > 0 ? { type: "paired", token: raw.token } : null;
      case "rejected":
        return raw.reason === "badToken" || raw.reason === "badCode" || raw.reason === "version" ? { type: "rejected", reason: raw.reason } : null;
      case "command": {
        const command = parseCommand(raw.command);
        return command ? { type: "command", command } : null;
      }
      case "artworkRequest":
        return typeof raw.requestId === "number" && typeof raw.url === "string" ? { type: "artworkRequest", requestId: raw.requestId, url: raw.url } : null;
      default:
        return null;
    }
  }
  const TOKEN_KEY = "focusScreenToken";
  const RECONNECT_MIN_MS = 1e3;
  const RECONNECT_MAX_MS = 3e4;
  const ARTWORK_TIMEOUT_MS = 8e3;
  const CONNECT_TIMEOUT_MS = 5e3;
  const UNREACHABLE = "Couldn’t reach Focus Screen. Make sure it’s open, then try again.";
  let socket = null;
  let status = "unpaired";
  let pairCode = null;
  let lastError = null;
  let reconnectDelay = RECONNECT_MIN_MS;
  let reconnectTimer;
  const tabs = /* @__PURE__ */ new Map();
  let shownTab = null;
  let lastLyrics = null;
  function send(message) {
    if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify(message));
  }
  async function storedToken() {
    const stored = await ext.storage.local.get(TOKEN_KEY);
    const token = stored[TOKEN_KEY];
    return typeof token === "string" ? token : null;
  }
  function sendShownState() {
    if (status !== "connected") return;
    send({ type: "state", state: shownTab === null ? null : tabs.get(shownTab)?.state ?? null });
  }
  function sendOnConnect() {
    sendShownState();
    if (lastLyrics) send({ type: "lyrics", lyrics: lastLyrics });
  }
  function updateShownTab() {
    const next = chooseTab(tabs, shownTab);
    const changed = next !== shownTab;
    shownTab = next;
    return changed;
  }
  let connecting = null;
  function connect() {
    connecting ??= openSocket().finally(() => {
      connecting = null;
    });
    return connecting;
  }
  async function openSocket() {
    if (socket) return;
    clearTimeout(reconnectTimer);
    const token = await storedToken();
    const pairing = pairCode !== null;
    if (!token && !pairing) {
      status = "unpaired";
      return;
    }
    status = "connecting";
    let ws;
    try {
      ws = new WebSocket(`ws://127.0.0.1:${EXTENSION_PORT}`);
    } catch (error) {
      lastError = `The browser blocked the connection (${String(error)}).`;
      status = token ? "offline" : "unpaired";
      pairCode = null;
      return;
    }
    socket = ws;
    let opened = false;
    const giveUp = setTimeout(() => {
      if (!opened) ws.close();
    }, CONNECT_TIMEOUT_MS);
    ws.onopen = () => {
      opened = true;
      clearTimeout(giveUp);
      if (pairCode) send({ type: "pair", version: PROTOCOL_VERSION, code: pairCode });
      else if (token) send({ type: "hello", version: PROTOCOL_VERSION, token });
      pairCode = null;
    };
    ws.onmessage = (event) => {
      if (typeof event.data !== "string") return;
      let raw;
      try {
        raw = JSON.parse(event.data);
      } catch {
        return;
      }
      const message = parseAppMessage(raw);
      if (message) void handleApp(message);
    };
    ws.onclose = () => {
      clearTimeout(giveUp);
      if (socket !== ws) return;
      socket = null;
      if (status !== "connected" && status !== "connecting") return;
      if (!opened) lastError = UNREACHABLE;
      if (pairing && !opened) {
        pairCode = null;
        status = token ? "offline" : "unpaired";
        return;
      }
      if (token) {
        status = "offline";
        scheduleReconnect();
      } else {
        status = "unpaired";
      }
    };
  }
  function scheduleReconnect() {
    clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(() => void connect(), reconnectDelay);
    reconnectDelay = Math.min(reconnectDelay * 2, RECONNECT_MAX_MS);
  }
  async function handleApp(message) {
    switch (message.type) {
      case "welcome":
        status = "connected";
        lastError = null;
        reconnectDelay = RECONNECT_MIN_MS;
        sendOnConnect();
        break;
      case "paired":
        await ext.storage.local.set({ [TOKEN_KEY]: message.token });
        status = "connected";
        lastError = null;
        reconnectDelay = RECONNECT_MIN_MS;
        sendOnConnect();
        break;
      case "rejected":
        if (message.reason === "badToken") await ext.storage.local.remove(TOKEN_KEY);
        status = message.reason === "badCode" ? "badCode" : "unpaired";
        lastError = message.reason === "version" ? "This extension and Focus Screen are different versions. Update both." : null;
        break;
      case "command":
        forwardCommand(message.command);
        break;
      case "artworkRequest":
        await sendArtwork(message.requestId, message.url);
        break;
    }
  }
  function forwardCommand(command) {
    if (shownTab === null) return;
    const message = { type: "command", command };
    ext.tabs.sendMessage(shownTab, message).catch(() => void 0);
  }
  async function sendArtwork(requestId, url) {
    try {
      if (!isArtworkUrl(url)) throw new Error("not a cover URL");
      const response = await fetch(url, {
        credentials: "omit",
        signal: AbortSignal.timeout(ARTWORK_TIMEOUT_MS)
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const bytes = new Uint8Array(await response.arrayBuffer());
      if (bytes.byteLength > MAX_ARTWORK_BYTES) throw new Error("cover too big");
      send({ type: "artwork", requestId, base64: toBase64(bytes) });
    } catch {
      send({ type: "artworkFailed", requestId });
    }
  }
  function isPageMessage(raw) {
    return typeof raw === "object" && raw !== null && "type" in raw && raw.type === "page";
  }
  function isLyricsMessage(raw) {
    return typeof raw === "object" && raw !== null && "type" in raw && raw.type === "lyrics";
  }
  function isPopupRequest(raw) {
    return typeof raw === "object" && raw !== null && "type" in raw && (raw.type === "status" || raw.type === "pair" || raw.type === "forget");
  }
  function popupStatus() {
    const state = shownTab === null ? null : tabs.get(shownTab)?.state ?? null;
    return {
      status,
      song: state ? [state.title, state.artist].filter(Boolean).join(" · ") : null,
      error: lastError
    };
  }
  async function handlePopup(request) {
    if (request.type === "pair") {
      pairCode = request.code.replace(/\D/g, "");
      lastError = null;
      const previous = socket;
      socket = null;
      previous?.close();
      await connect();
    } else if (request.type === "forget") {
      await ext.storage.local.remove(TOKEN_KEY);
      status = "unpaired";
      lastError = null;
      clearTimeout(reconnectTimer);
      const previous = socket;
      socket = null;
      previous?.close();
    }
    return popupStatus();
  }
  ext.runtime.onMessage.addListener((raw, sender, sendResponse) => {
    const tabId = sender.tab?.id;
    if (tabId !== void 0 && isPageMessage(raw)) {
      tabs.set(tabId, { state: raw.state, at: Date.now() });
      const shownChanged = updateShownTab();
      if (shownChanged || tabId === shownTab) sendShownState();
      if (!socket) void connect();
      return false;
    }
    if (tabId !== void 0 && isLyricsMessage(raw)) {
      lastLyrics = raw.lyrics;
      if (status === "connected") send({ type: "lyrics", lyrics: raw.lyrics });
      else if (!socket) void connect();
      return false;
    }
    if (tabId === void 0 && isPopupRequest(raw)) {
      handlePopup(raw).then(sendResponse, () => sendResponse(popupStatus()));
      return true;
    }
    return false;
  });
  ext.runtime.onConnect.addListener((port) => {
    if (port.name !== PAGE_LINE || port.sender?.tab?.id === void 0) return;
    if (!socket) void connect();
  });
  ext.tabs.onRemoved.addListener((tabId) => {
    if (!tabs.delete(tabId)) return;
    updateShownTab();
    sendShownState();
  });
  async function wake() {
    const open = await Promise.resolve().then(() => ext.tabs.query({ url: "https://music.youtube.com/*" })).catch(() => []);
    const ask = { type: "report" };
    for (const tab of open) {
      if (tab.id !== void 0) ext.tabs.sendMessage(tab.id, ask).catch(() => void 0);
    }
    await connect();
  }
  ext.runtime.onStartup?.addListener(() => void wake());
  ext.runtime.onInstalled?.addListener(() => void wake());
  void wake();
})();
