(function() {
  "use strict";
  const PAGE_LINE = "focus-screen-page";
  const ext = typeof browser !== "undefined" && browser ? browser : chrome;
  function isArtworkUrl(value) {
    let url;
    try {
      url = new URL(value);
    } catch {
      return false;
    }
    const host = url.hostname;
    return url.protocol === "https:" && !url.username && !url.password && !url.port && (host.endsWith(".googleusercontent.com") || host === "i.ytimg.com" || host.endsWith(".ggpht.com"));
  }
  const REPEAT_ORDER = ["off", "all", "one"];
  const SEEK_TOLERANCE_SEC = 1.5;
  function parseRepeatTitle(title) {
    const text = (title ?? "").toLowerCase();
    if (text.endsWith(" one")) return "one";
    if (text.endsWith(" all")) return "all";
    return "off";
  }
  function clicksToRepeat(current, target) {
    const from = REPEAT_ORDER.indexOf(current);
    const to = REPEAT_ORDER.indexOf(target);
    return (to - from + REPEAT_ORDER.length) % REPEAT_ORDER.length;
  }
  function splitByline(byline) {
    const [artist = "", album = ""] = byline.split("•").map((part) => part.trim());
    return { artist, album: /^\d{4}$/.test(album) ? "" : album };
  }
  function bestArtwork(artwork) {
    const sized = artwork.map((art) => ({
      src: art.src,
      side: Number.parseInt((art.sizes ?? "").split("x")[0] ?? "", 10) || 0
    }));
    const fitting = sized.filter((art) => art.side <= 600).sort((a, b) => b.side - a.side);
    const any = [...sized].sort((a, b) => b.side - a.side);
    return fitting[0]?.src ?? any[0]?.src ?? null;
  }
  function parseQueueDuration(text) {
    const parts = text.trim().split(":");
    if (parts.length < 2 || parts.length > 3 || !parts.every((part) => /^\d{1,2}$/.test(part))) {
      return 0;
    }
    return parts.reduce((total, part) => total * 60 + Number(part), 0);
  }
  const QUEUE_COVER_REQUEST = "focus-screen-queue-cover";
  const QUEUE_COVER_ATTRIBUTE = "data-focus-screen-cover";
  const UP_NEXT_COVER_PX = 160;
  function queueCover(sizes, imgSrc) {
    const covers = parseCoverSizes(sizes);
    const fitting = covers.filter((art) => art.side >= UP_NEXT_COVER_PX).sort((a, b) => a.side - b.side);
    const any = [...covers].sort((a, b) => b.side - a.side);
    return fitting[0]?.url ?? any[0]?.url ?? (isArtworkUrl(imgSrc) ? imgSrc : null);
  }
  function parseCoverSizes(raw) {
    if (raw === null) return [];
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return [];
    }
    if (!Array.isArray(parsed)) return [];
    return parsed.flatMap(
      (entry) => isRecord(entry) && typeof entry.url === "string" && isArtworkUrl(entry.url) ? [{ url: entry.url, side: Number.isFinite(entry.width) ? Number(entry.width) : 0 }] : []
    );
  }
  function upNextIndex(slots, autoplay, repeat) {
    if (repeat === "one") return null;
    const current = slots.findIndex((slot) => slot.selected);
    if (current < 0) return null;
    const following = slots[current + 1];
    if (following && (!following.automix || autoplay)) return current + 1;
    return repeat === "all" && current > 0 ? 0 : null;
  }
  function stateChanged(last2, next, elapsedSec) {
    if (last2 === void 0) return true;
    if (last2 === null || next === null) return last2 !== next;
    const { positionSec: lastPosition, ...lastRest } = last2;
    const { positionSec: nextPosition, ...nextRest } = next;
    if (JSON.stringify(lastRest) !== JSON.stringify(nextRest)) return true;
    const expected = lastPosition + (last2.playing ? elapsedSec : 0);
    return Math.abs(nextPosition - expected) > SEEK_TOLERANCE_SEC;
  }
  const NEW_LYRICS_WATCH = {
    song: void 0,
    stale: null,
    seen: null,
    sent: null
  };
  const LYRICS_STEADY_MS = 1e3;
  function watchLyrics(watch, song, panel, shown, now) {
    const current = song === watch.song ? watch : { song, stale: watch.song === void 0 ? null : panel, seen: null, sent: null };
    if (!shown || !panel || panel === current.stale || panel === current.sent) {
      return { watch: { ...current, seen: null }, send: null };
    }
    if (current.seen?.text !== panel) {
      return { watch: { ...current, seen: { text: panel, at: now } }, send: null };
    }
    if (now - current.seen.at < LYRICS_STEADY_MS) return { watch: current, send: null };
    return { watch: { ...current, seen: null, sent: panel }, send: panel };
  }
  function lyricsCredit(footer) {
    const name = footer.split(/[:：]/).pop()?.trim() ?? "";
    return name === "" ? null : name.slice(0, 60);
  }
  const LINE_HEALTHY_MS = 5e3;
  const LINE_RETRY_MIN_MS = 1e3;
  const LINE_RETRY_MAX_MS = 3e4;
  function lineRetryMs(openMs, lastWaitMs) {
    if (openMs >= LINE_HEALTHY_MS) return 0;
    return Math.min(Math.max(lastWaitMs * 2, LINE_RETRY_MIN_MS), LINE_RETRY_MAX_MS);
  }
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  const CHECK_MS = 1e3;
  const HEARTBEAT_MS = 5e3;
  const IDLE_HEARTBEAT_MS = 1e4;
  const CLICK_GAP_MS = 150;
  const GONE_AFTER_MS = 3e3;
  let last;
  let lastSentAt = 0;
  let goneSince = null;
  let stopped = false;
  const playerBar = () => document.querySelector("ytmusic-player-bar");
  const video = () => document.querySelector("video");
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  function textOf(selector) {
    return playerBar()?.querySelector(selector)?.textContent?.trim() ?? "";
  }
  function rowCover(row) {
    row.dispatchEvent(new Event(QUEUE_COVER_REQUEST));
    const sizes = row.getAttribute(QUEUE_COVER_ATTRIBUTE);
    row.removeAttribute(QUEUE_COVER_ATTRIBUTE);
    return queueCover(sizes, row.querySelector("img")?.src ?? "");
  }
  function readUpNext(repeat) {
    const items = [
      ...document.querySelectorAll("ytmusic-player-queue ytmusic-player-queue-item")
    ].filter((item2) => item2.closest("#counterpart-renderer") === null);
    const toggle = document.querySelector("ytmusic-player-page #automix");
    const autoplay = toggle === null || toggle.getAttribute("aria-pressed") !== "false";
    const index = upNextIndex(
      items.map((item2) => ({
        selected: item2.hasAttribute("selected"),
        automix: item2.hasAttribute("is-automix")
      })),
      autoplay,
      repeat
    );
    const item = index === null ? void 0 : items[index];
    const title = item?.querySelector(".song-title")?.textContent?.trim() ?? "";
    if (!item || !title) return null;
    return {
      title,
      artist: splitByline(item.querySelector(".byline")?.textContent ?? "").artist,
      durationSec: parseQueueDuration(item.querySelector(".duration")?.textContent ?? ""),
      artworkUrl: rowCover(item)
    };
  }
  function readState() {
    const media = video();
    const metadata = navigator.mediaSession?.metadata ?? null;
    const title = metadata?.title || textOf(".title");
    if (!media || !title || !(media.duration > 0)) return null;
    const byline = splitByline(textOf(".byline"));
    const image = playerBar()?.querySelector("img.image")?.src ?? null;
    const params = new URL(location.href).searchParams;
    const videoId = params.get("v");
    const playlistId = params.get("list")?.trim().slice(0, 200) || null;
    const repeat = parseRepeatTitle(playerBar()?.querySelector(".repeat")?.getAttribute("title"));
    const ad = document.querySelector(".ad-showing") !== null;
    return {
      videoId,
      playlistId,
      title,
      artist: metadata?.artist || byline.artist,
      album: metadata?.album || byline.album,
      durationSec: Number.isFinite(media.duration) ? media.duration : 0,
      positionSec: media.currentTime,
      playing: !media.paused && !media.ended,
      // The button looks the same either way; the player bar carries the state as an attribute.
      shuffle: playerBar()?.hasAttribute("shuffle-on") ?? null,
      repeat,
      artworkUrl: bestArtwork(metadata ? [...metadata.artwork] : []) ?? image,
      ad,
      next: ad ? null : readUpNext(repeat)
    };
  }
  const LYRICS_PANEL = 'ytmusic-description-shelf-renderer[page-type="MUSIC_PAGE_TYPE_TRACK_LYRICS"]';
  let lyricsWatch = NEW_LYRICS_WATCH;
  function checkLyrics(state) {
    if (!state || state.ad) return;
    const panel = document.querySelector(LYRICS_PANEL);
    const words = panel?.querySelector("yt-formatted-string.description")?.innerText.trim();
    const song = state.videoId ?? `${state.title}
${state.artist}`;
    const { watch, send } = watchLyrics(
      lyricsWatch,
      song,
      words || null,
      panel !== null && panel.getClientRects().length > 0,
      Date.now()
    );
    lyricsWatch = watch;
    if (!send || !panel) return;
    const footer = panel.querySelector("yt-formatted-string.footer")?.textContent ?? "";
    const message = {
      type: "lyrics",
      lyrics: {
        videoId: state.videoId,
        title: state.title,
        artist: state.artist,
        text: send,
        source: lyricsCredit(footer)
      }
    };
    ext.runtime.sendMessage(message).catch(() => {
      if (lyricsWatch.sent === send) lyricsWatch = { ...lyricsWatch, sent: null };
    });
  }
  function report(force = false) {
    if (stopped) return;
    const state = readState();
    checkLyrics(state);
    const now = Date.now();
    if (state === null && last) {
      goneSince ??= now;
      if (now - goneSince < GONE_AFTER_MS) return;
    } else {
      goneSince = null;
    }
    const heartbeatDue = now - lastSentAt >= (state?.playing ? HEARTBEAT_MS : IDLE_HEARTBEAT_MS);
    if (!force && !heartbeatDue && !stateChanged(last, state, (now - lastSentAt) / 1e3)) return;
    last = state;
    lastSentAt = now;
    const message = { type: "page", state };
    ext.runtime.sendMessage(message).catch(() => {
      if (!ext.runtime.id) stopped = true;
      else lastSentAt = 0;
    });
  }
  function press(selector) {
    const host = playerBar()?.querySelector(selector);
    if (!host) return false;
    (host.querySelector("button") ?? host).click();
    return true;
  }
  async function run(command) {
    switch (command.kind) {
      case "playPause":
        press("#play-pause-button");
        break;
      case "next":
        press(".next-button");
        break;
      case "previous":
        press(".previous-button");
        break;
      case "restart": {
        const media = video();
        if (media) media.currentTime = 0;
        break;
      }
      case "seek": {
        const media = video();
        if (media && media.duration > 0) {
          media.currentTime = Math.min(command.positionSec, media.duration);
        }
        break;
      }
      case "setShuffle":
        if ((playerBar()?.hasAttribute("shuffle-on") ?? false) !== command.on) press(".shuffle");
        break;
      case "setRepeat": {
        const current = parseRepeatTitle(playerBar()?.querySelector(".repeat")?.getAttribute("title"));
        for (let i = clicksToRepeat(current, command.mode); i > 0; i--) {
          press(".repeat");
          await wait(CLICK_GAP_MS);
        }
        break;
      }
    }
    for (const delay of [50, 300, 1200]) setTimeout(() => report(), delay);
  }
  function isTabMessage(raw) {
    return typeof raw === "object" && raw !== null && "type" in raw;
  }
  ext.runtime.onMessage.addListener((raw) => {
    if (!isTabMessage(raw)) return;
    if (raw.type === "command") void run(raw.command);
    else report(true);
  });
  let lineWaitMs = 0;
  function holdLine() {
    if (stopped) return;
    const openedAt = Date.now();
    try {
      ext.runtime.connect({ name: PAGE_LINE }).onDisconnect.addListener(() => {
        if (!ext.runtime.id) {
          stopped = true;
          return;
        }
        lineWaitMs = lineRetryMs(Date.now() - openedAt, lineWaitMs);
        if (lineWaitMs === 0) holdLine();
        else setTimeout(holdLine, lineWaitMs);
      });
    } catch {
      stopped = true;
    }
  }
  for (const event of ["play", "pause", "seeked", "ended", "durationchange", "emptied"]) {
    document.addEventListener(event, () => report(), true);
  }
  setInterval(() => report(), CHECK_MS);
  report(true);
  holdLine();
})();
