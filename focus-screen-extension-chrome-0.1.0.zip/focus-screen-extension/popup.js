(function() {
  "use strict";
  const ext = typeof browser !== "undefined" && browser ? browser : chrome;
  const REFRESH_MS = 700;
  const ANSWER_TIMEOUT_MS = 2e3;
  const HOW_TO_PAIR = "In Focus Screen, open Customize → Music → Connect Browser Extension…, then type the code here.";
  const COPY = {
    connected: { text: "Connected", tone: "ok" },
    connecting: { text: "Connecting…", tone: "idle" },
    offline: { text: "Focus Screen isn’t running", tone: "error" },
    unpaired: { text: "Not connected yet", tone: "idle" },
    badCode: { text: "That code didn’t work", tone: "error" }
  };
  function element(id) {
    const found = document.getElementById(id);
    if (!found) throw new Error(`Missing #${id}`);
    return found;
  }
  const statusRow = element("status");
  const statusText = element("status-text");
  const detail = element("detail");
  const form = element("pair");
  const codeInput = element("code");
  const submit = element("connect");
  const forget = element("forget");
  function isPopupStatus(value) {
    return typeof value === "object" && value !== null && "status" in value;
  }
  async function ask(request) {
    const timedOut = new Promise(
      (resolve) => setTimeout(() => resolve("no answer within 2 seconds"), ANSWER_TIMEOUT_MS)
    );
    const reply = await Promise.race([
      Promise.resolve().then(() => ext.runtime.sendMessage(request)).catch((error) => String(error)),
      timedOut
    ]);
    if (isPopupStatus(reply)) {
      render(reply);
      return;
    }
    statusRow.dataset.tone = "error";
    statusText.textContent = "Extension isn’t ready";
    detail.textContent = `Its background part didn’t answer${typeof reply === "string" ? ` (${reply})` : ""}. Turn the extension off and on in the browser’s settings.`;
  }
  function render({ status, song, error }) {
    const copy = COPY[status];
    statusRow.dataset.tone = copy.tone;
    statusText.textContent = copy.text;
    form.hidden = status === "connected";
    submit.disabled = status === "connecting";
    forget.hidden = status !== "connected" && status !== "offline";
    detail.textContent = error ?? (status === "connected" ? song ? `Showing: ${song}` : "Play something on music.youtube.com." : status === "offline" ? "It reconnects by itself once Focus Screen is open. You can also enter a new code." : status === "badCode" ? `Codes work once, for 5 minutes. ${HOW_TO_PAIR}` : status === "connecting" ? "Talking to Focus Screen…" : HOW_TO_PAIR);
  }
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const code = codeInput.value.replace(/\D/g, "");
    if (code.length !== 6) return;
    codeInput.value = "";
    void ask({ type: "pair", code });
  });
  forget.addEventListener("click", () => void ask({ type: "forget" }));
  void ask({ type: "status" });
  setInterval(() => void ask({ type: "status" }), REFRESH_MS);
})();
