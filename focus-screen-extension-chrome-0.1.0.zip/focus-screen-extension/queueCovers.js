(function() {
  "use strict";
  const QUEUE_COVER_REQUEST = "focus-screen-queue-cover";
  const QUEUE_COVER_ATTRIBUTE = "data-focus-screen-cover";
  document.addEventListener(
    QUEUE_COVER_REQUEST,
    (event) => {
      const row = event.target;
      if (!(row instanceof HTMLElement) || row.localName !== "ytmusic-player-queue-item") return;
      const sizes = row.data?.thumbnail?.thumbnails;
      if (Array.isArray(sizes)) row.setAttribute(QUEUE_COVER_ATTRIBUTE, JSON.stringify(sizes));
    },
    true
  );
})();
